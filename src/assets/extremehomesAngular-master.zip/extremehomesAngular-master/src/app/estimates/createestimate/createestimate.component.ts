import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createestimate',
  templateUrl: './createestimate.component.html',
  styleUrls: ['./createestimate.component.css']
})
export class CreateestimateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
