export interface IEstimate{
    id : any,
    customer : any,
    workType : any,
    difficulty: any,
    condition : any,
    hours : any,
    workDescription : any,
    tasks: any,
    materials : any,
    materialOverview : any,
    images : any,
    dateCreated : any
}