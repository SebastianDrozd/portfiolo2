import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individualcustomer',
  templateUrl: './individualcustomer.component.html',
  styleUrls: ['./individualcustomer.component.css']
})
export class IndividualcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
